import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class notification extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int x=0;	
	response.setContentType("text/html");
	PrintWriter out=response.getWriter();
	try
	{
		
		RequestDispatcher rd=request.getRequestDispatcher("part.html");
		rd.include(request,response);
		
		String[] breakfast=request.getParameterValues("breakfast");
		String[] lunch=request.getParameterValues("lunch");
		String[] snacks=request.getParameterValues("snacks");
		String[] dinner=request.getParameterValues("dinner");
		
		
		out.println("<html>");
		out.println("<head>");
		out.println("<style>");
		out.println("table {");
		out.println("    font-family: arial, sans-serif;");
		out.println("    border-collapse: collapse;");
		out.println("    width: 100%;");
		out.println("}");

		out.println("td, th {");
		out.println("    border: 1px solid #dddddd;");
		out.println("    text-align: left;");
		out.println("    padding: 8px;");
		out.println("}");

		out.println("tr:nth-child(even) {");
		out.println("    background-color: #dddddd;");
		out.println("}");
		out.println("</style>");
		out.println("</head>");
		out.println("<body>");


out.println("<h2>Todays menu</h2>");

out.println("<table>");
out.println("  <tr>");
out.println("<th>BreakFast</th>");
for(String s1:breakfast)
{
   out.println("<td>"+s1+"</td>");
}
 out.println(" </tr>");

 out.println("  <tr>");
 out.println("<th>Lunch</th>");
 for(String s2:lunch)
 {
    out.println("<td>"+s2+"</td>");
 }
  out.println(" </tr>");

  out.println("  <tr>");
  out.println("<th>Snacks</th>");
  for(String s3:snacks)
  {
     out.println("<td>"+s3+"</td>");
  }
   out.println(" </tr>");

   out.println("  <tr>");
   out.println("<th>Dinner</th>");
   for(String s4:dinner)
   {
      out.println("<td>"+s4+"</td>");
   }
    out.println(" </tr>");
    out.println("</table>");	
    
    out.println("<form>");
    out.println("<textarea name=message rows=10 cols=30>The cat was playing");
    out.println("in the garden.</textarea>");
    out.println(" <br>");
   out.println("  <input type=submit value=reply");
   out.println("</form>");

out.println("</body>");
out.println("</html>");
		
	}
	catch(Exception e)
	{
	e.printStackTrace();
	}
	


    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
RequestDispatcher rd=request.getRequestDispatcher("part.html");
		rd.include(request,response);
		        try {
            Class.forName("com.mysql.jdbc.Driver");
     
               Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mess","root","root");
               Statement s=con.createStatement();
               s.executeUpdate("delete * from breakfast");
               Statement ss1=con.prepareStatement("delete * from lunch");
               ss1.executeUpdate("delete * from breakfast");
               Statement s2=con.prepareStatement("delete * from snacks1");
               s2.executeUpdate("delete * from breakfast");
               Statement s3=con.prepareStatement("delete * from dinner");
		s3.executeUpdate("delete * from breakfast");
               PreparedStatement ps=con.prepareStatement("select * from breakfast");
                ResultSet rs=ps.executeQuery();
                while(rs.next())
                {
                out.println(rs.getString(1));
                }
                out.println("<html>");
		out.println("<head>");
		out.println("<style>");
		out.println("table {");
		out.println("    font-family: arial, sans-serif;");
		out.println("    border-collapse: collapse;");
		out.println("    width: 100%;");
		out.println("}");

		out.println("td, th {");
		out.println("    border: 1px solid #dddddd;");
		out.println("    text-align: left;");
		out.println("    padding: 8px;");
		out.println("}");

		out.println("tr:nth-child(even) {");
		out.println("    background-color: #dddddd;");
		out.println("}");
		out.println("</style>");
		out.println("</head>");
		out.println("<body>");


out.println("<h2>Todays menu</h2>");
out.println("<table>");
out.println("  <tr>");
out.println("<th>BreakFast</th>");


                if(rs.next())
                {
                    do
                    {
                String s1=rs.getString(1);
                        out.println("<td>"+s1+"</td>");
   
                    }while(rs.next());
                }
                out.println("</tr>");
                

out.println("  <tr>");
out.println("<th>Lunch</th>");
                PreparedStatement ps1=con.prepareStatement("select * from lunch");
                rs=ps1.executeQuery();
                if(rs.next())
                {
                    do
                    {
                String s1=rs.getString(1);
                        out.println("<td>"+s1+"</td>");
                    }while(rs.next());
                }
                out.println("</tr>");
                
out.println("  <tr>");
out.println("<th>snacks</th>");
                PreparedStatement ps2=con.prepareStatement("select * from snacks1");
                rs=ps2.executeQuery();
                if(rs.next())
                {
                    do
                    {
                String s1=rs.getString(1);
                        out.println("<td>"+s1+"</td>");
                    }while(rs.next());
                }
                out.println("</tr>");
                
out.println("  <tr>");
out.println("<th>Dinner</th>");
                PreparedStatement ps3=con.prepareStatement("select * from dinner");
                rs=ps3.executeQuery();
                if(rs.next())
                {
                    do
                    {
                String s1=rs.getString(1);
                        out.println("<td>"+s1+"</td>");
                    }while(rs.next());
                }
                out.println("</tr>");
                out.println("</table>");
                out.println("</body>");
                out.println("</html>");
                
} catch (ClassNotFoundException ex) {
            Logger.getLogger(notification.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(notification.class.getName()).log(Level.SEVERE, null, ex);
        }
     
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
